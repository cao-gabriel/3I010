#ifndef _LRUSWAPPER_H_
#define _LRUSWAPPER_H_

#include "Swapper.h"

int initMFUSwapper(Swapper*,unsigned int); //nb of physical pages

#endif
